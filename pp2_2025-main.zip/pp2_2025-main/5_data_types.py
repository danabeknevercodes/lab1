x = tuple(("apple", "banana", "cherry"))
print(x)