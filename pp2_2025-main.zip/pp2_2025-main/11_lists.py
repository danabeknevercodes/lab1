thislist = [100, 50, 65, 82, 23]
thislist.sort(reverse = True)
print(thislist)