x = 5
y = 'John'
print(type(x))
print(type(y))

a = str(3)    # a will be '3'
b = int(3)    # b will be 3
c = float(3)  # c will be 3.0

#Legal variable names:
myvar = "John"
my_var = "John"
_my_var = "John"
myVar = "John"
MYVAR = "John"
myvar2 = "John"

"""
fruits = ["apple", "banana", "cherry"]
x, y, z = fruits
print(x)
print(y)
print(z)
"""